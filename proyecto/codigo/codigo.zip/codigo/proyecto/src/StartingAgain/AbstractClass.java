/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StartingAgain;

import java.io.File;

/**
 *
 * @author evinracher
 */
public abstract class AbstractClass {

    private File identificador;
    private String texto;
    
    public AbstractClass(File file) {
        this.identificador = file;
    }
    
    public AbstractClass(String texto){
        File archivo = new File("./"+texto);
        this.identificador = archivo;
    }

    public String getNombre() {
        return identificador.getName();
    }
    
    public File getFile(){
        return this.identificador;
    }
    
}
