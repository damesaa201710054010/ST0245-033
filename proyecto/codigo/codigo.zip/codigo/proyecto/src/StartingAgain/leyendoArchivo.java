package StartingAgain;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class leyendoArchivo {
    private static String putoArchivo = "j";
    
    public leyendoArchivo(){
        ejecucion();
    }
    public String obtArchivo(){
        return putoArchivo;
    }
    
    public void ejecucion(){
    //Codigo tomado de(solo lo de la lectura, el resto de metodos son propios):https://www.aprenderaprogramar.com/index.php?option=com_content&view=article&id=466:operadores-logicos-en-java-igual-distinto-and-or-not-mayor-menor-cortocircuito-cu00634b&catid=68&Itemid=188

        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        String Lectura = "";

        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            archivo = new File("/home/evinracher/prueba/ejemplito.txt");
            fr = new FileReader(archivo);
            br = new BufferedReader(fr);

            // Lectura del fichero
            String linea;
            while ((linea = br.readLine()) != null) {
                //System.out.println(linea);
                Lectura = Lectura + linea + "\n";
            }

            //System.out.println(Lectura);
            String primeraLimpieza = limpieza(Lectura);
            //System.out.println(primeraLimpieza);
            String segundaLimpieza = igUsuario(primeraLimpieza);
            //System.out.println(segundaLimpieza);
            String traLimp = conEsp(segundaLimpieza);
            //System.out.println(traLimp);
            String conTypes = cont(quitarLast(traLimp));
            putoArchivo = type(conTypes);
            //System.out.println(putoArchivo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta 
            // una excepcion.
            try {
                if (null != fr) {
                    fr.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }

    }
    public static void main(String[] args) throws FileNotFoundException, IOException {
        //Codigo tomado de(solo lo de la lectura, el resto de metodos son propios):https://www.aprenderaprogramar.com/index.php?option=com_content&view=article&id=466:operadores-logicos-en-java-igual-distinto-and-or-not-mayor-menor-cortocircuito-cu00634b&catid=68&Itemid=188

        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;
        String Lectura = "";

        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            archivo = new File("/home/evinracher/prueba/ejemplito.txt");
            fr = new FileReader(archivo);
            br = new BufferedReader(fr);

            // Lectura del fichero
            String linea;
            while ((linea = br.readLine()) != null) {
                //System.out.println(linea);
                Lectura = Lectura + linea + "\n";
            }

            //System.out.println(Lectura);
            String primeraLimpieza = limpieza(Lectura);
            //System.out.println(primeraLimpieza);
            String segundaLimpieza = igUsuario(primeraLimpieza);
            //System.out.println(segundaLimpieza);
            String traLimp = conEsp(segundaLimpieza);
            //System.out.println(traLimp);
            String conTypes = cont(quitarLast(traLimp));
            putoArchivo = type(conTypes);
            System.out.println(putoArchivo);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta 
            // una excepcion.
            try {
                if (null != fr) {
                    fr.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    public static String limpieza(String line) {
        String nueva = "";
        for (int i = 0; i < line.length(); ++i) {
            if ((line.charAt(i) != '│') && (line.charAt(i) != '├') && (line.charAt(i) != '─') && (line.charAt(i) != '└')) {
                nueva = nueva + line.charAt(i);
            }
        }
        return nueva;
    }

    public static String igUsuario(String line) {
        String nueva = "";
        for (int i = 0; i < line.length(); ++i) {
            if ((line.charAt(i) == '[')) {
                int j = i;
                while (line.charAt(j) != ']') {
                    j++;
                }
                i = j + 1;
            }
            nueva = nueva + line.charAt(i);
        }
        return nueva;
    }

    public static String conEsp(String line) {
        String nueva = "";
        for (int i = 0; i < line.length(); ++i) {
            if (line.charAt(i) == '\n' && i + 1 < line.length()) {
                nueva = nueva + line.charAt(i);
                int j;
                for (j = i; line.charAt(j) != ' '; ++j) {
                }
                i = j;

            } else {
                nueva = nueva + line.charAt(i);
            }
        }
        return nueva;

    }

    public static String quitarLast(String line) {
        String nueva = "";
        int cont = 0;
        for (int i = line.length() - 1; line.charAt(i) != ' '; --i) {
            cont++;
        }

        for (int i = line.length() - cont - 1; line.charAt(i) != '\n'; --i) {
            cont++;
        }
        return line.substring(0, line.length() - cont - 1);

    }

    public static String type(String line) {
        String nueva = "";
        boolean punto = false;
        nueva = nueva + line.charAt(0);
        for (int i = 1; i < line.length(); ++i) {
            if (line.codePointAt(i) == 10 && i + 1 < line.length()) {
                nueva = nueva + line.charAt(i);
                for (int j = i+1; line.charAt(j) != '\n' && j+1 < line.length(); ++j) {
                    if (line.charAt(j) == '.') {
                        punto = true;
                        break;
                    }
                }
                if (punto) {
                    nueva = nueva +"<A>";
                }else{
                    nueva = nueva + "<C>";
                }
                punto = false;
            }else{
              nueva = nueva + line.charAt(i);
            }

        }
        return nueva;
    }

    public static String cont(String line) {
        String nueva = "";
        int cont = 0;
        for (int i = 0; i < line.length(); ++i) {
            if (line.codePointAt(i) == 10 && i + 1 < line.length()) {
                nueva = nueva + line.charAt(i);
                int j;
                for (j = i + 1; line.charAt(j) == ' '; ++j) {
                    cont++;
                }
                i = j - 1;
                nueva = nueva + "[" + cont + "]";
                cont = 0;
            } else {
                nueva = nueva + line.charAt(i);
            }
        }
        return nueva;

    }

}
