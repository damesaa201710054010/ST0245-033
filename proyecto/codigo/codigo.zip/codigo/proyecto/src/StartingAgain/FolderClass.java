package StartingAgain;

import java.io.File;
import java.util.LinkedList;

public class FolderClass extends AbstractClass {

    private String space;
    private LinkedList<AbstractClass> archivos;
    private String lastCarp;

    public FolderClass(File file, String space) {
        super(file);
        archivos = new LinkedList<>();
        generadorLinked(file.listFiles());
        this.space = space;
    }
    
    public FolderClass(String file, String space) {
        super(file);
        archivos = new LinkedList<>();
        generarLinkedArch(file);
        this.space = space;
    }

    public void generadorLinked(File[] file) {
        for (int x = 0; x < file.length; x++) {
            if (file[x].isFile()) {
                archivos.add(new Archivo(file[x]));
            } else if (file[x].isDirectory()) {
                archivos.add(new FolderClass(file[x], space));
            }
        }
    }
    
    public void generarLinkedArch(String archivo){
        int cont = 0;
        for(int i = 0; i < archivo.length();i++){
            if(archivo.charAt(i) == '<'){
                if(archivo.charAt(i+1) == 'A'){
                    String nombre = "";
                    int j = i + 6;
                    for(; j < archivo.length() && archivo.charAt(j) != '\n';++j){
                        nombre = nombre + archivo.charAt(j);
                    }
                    i = j;
                    Archivo n = new Archivo(nombre);
                    archivos.add(n);
                    System.out.println(archivos.get(cont).getNombre());
                    cont++;
                    nombre = "";
                }
            }
        }
    }
     public void listarSimple(){
         for(int i = 0; i < archivos.size(); ++i){
             System.out.println(archivos.get(i).getNombre());
         }
     }

    public void listar(String space) {
        for (int x = 0; x < archivos.size(); ++x) {
            if (archivos.get(x) instanceof Archivo) {
                System.out.println(space + "Archivo: " + archivos.get(x).getNombre());
            } else if (archivos.get(x) instanceof FolderClass) {
                System.out.println(space + "Carpeta: " + archivos.get(x).getNombre());
                String esp = space + "-";
                FolderClass p = (FolderClass) archivos.get(x);
                p.listar(esp);
            }
        }
    }

    public boolean eliminar(String name) {
        for (int x = 0; x < archivos.size(); ++x) {
            if (archivos.get(x) instanceof Archivo) {
                if (archivos.get(x).getNombre().equals(name)) {
                    System.out.println("Eliminando el archvio en:\n " + archivos.get(x).getFile());
                    File aBorrar = archivos.get(x).getFile();
                    aBorrar.delete();
                    archivos.remove(x);
                    return true;
                }
            } else if (archivos.get(x) instanceof FolderClass) {
                if (archivos.get(x).getNombre().equals(name)) {
                    System.out.println("Eliminando el archvio en:\n " + archivos.get(x).getFile());
                    File aBorrar = archivos.get(x).getFile();
                    aBorrar.delete();
                    archivos.remove(x);
                    return true;
                } else {
                    FolderClass p = (FolderClass) archivos.get(x);
                    p.eliminar(name);
                }
            }

        }
        return false;
    }

    public String buscar(String name) {
        String re = "";
        for (int x = 0; x < archivos.size(); ++x) {
            if (archivos.get(x) instanceof Archivo) {
                if (archivos.get(x).getNombre().equals(name)) {
                    lastCarp = archivos.get(x).getFile().getParent();
                    re = ("El archvio existe:\n " + archivos.get(x).getFile());
                }
            } else if (archivos.get(x) instanceof FolderClass) {
                if (archivos.get(x).getNombre().equals(name)) {
                    lastCarp = archivos.get(x).getFile().toString();
                    re = ("El archvio existe:\n " + archivos.get(x).getFile());
                    break;

                } else {
                    FolderClass p = (FolderClass) archivos.get(x);
                    re = p.buscar(name);                            
                }
            }

        }
        return re;
    }

    public String obtLastDir() {
        return lastCarp;
    }

    public boolean crear(String dir) {
        return false;
    }

}
